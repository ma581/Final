
function y = min2(x);
y = min(min(double(x)));