function varargout=CutSquare(Lc,i,n,varargin)
%this function cuts a square around the labled object i with margin n.
%Other images that correspond to the labled image can be introduced as the
%varargin and will be cut in the same way.

if nargin==2
    n=0;
end
c=Lc==i;
[I,J]=find(Lc==i);
c0=c(max(min(I)-n,1):min(max(I)+n,size(Lc,1)),max(min(J)-n,1):min(max(J)+n,size(Lc,2)));
varargout{1}=c0;
for i=1:length(varargin)
    varargout{i+1}=varargin{i}(max(min(I)-n,1):min(max(I)+n,size(Lc,1)),max(min(J)-n,1):min(max(J)+n,size(Lc,2)));
end