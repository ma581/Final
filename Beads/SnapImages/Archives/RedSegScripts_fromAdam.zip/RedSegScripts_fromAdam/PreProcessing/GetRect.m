function varargout=GetRect(varargin)

k = waitforbuttonpress;
point1 = get(gca,'CurrentPoint');    % button down detected
finalRect = rbbox;                   % return figure units
point2 = get(gca,'CurrentPoint');    % button up detected
point1 = point1(1,1:2);              % extract x and y
point2 = point2(1,1:2);
p1 = round(min(point1,point2));             % calculate locations
offset = round(abs(point1-point2));         % and dimensions
if nargout==0
x = [p1(1) p1(1)+offset(1) p1(1)+offset(1) p1(1) p1(1)];
y = [p1(2) p1(2) p1(2)+offset(2) p1(2)+offset(2) p1(2)];
hold on
axis manual
plot(x,y)
else
    varargout{1}=[p1 offset];    
    if nargin>=1 & nargout>1
        for i=1:length(varargin)
            varargout{i+1}=varargin{i}(p1(2):p1(2)+offset(2),p1(1):p1(1)+offset(1));
        end
    end
end