function varargout = MovieCropGUI(varargin)
% MOVIECROPGUI M-file for MovieCropGUI.fig
%      MOVIECROPGUI, by itself, creates a new MOVIECROPGUI or raises the existing
%      singleton*.
%
%      H = MOVIECROPGUI returns the handle to a new MOVIECROPGUI or the handle to
%      the existing singleton*.
%
%      MOVIECROPGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MOVIECROPGUI.M with the given input arguments.
%
%      MOVIECROPGUI('Property','Value',...) creates a new MOVIECROPGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MovieCropGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property
%      application
%      stop.  All inputs are passed to MovieCropGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MovieCropGUI

% Last Modified by GUIDE v2.5 06-Sep-2008 15:32:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @MovieCropGUI_OpeningFcn, ...
    'gui_OutputFcn',  @MovieCropGUI_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before MovieCropGUI is made visible.
function MovieCropGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MovieCropGUI (see VARARGIN)

% Choose default command line output for MovieCropGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MovieCropGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

end
% --- Outputs from this function are returned to the command line.
function varargout = MovieCropGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

end


function Directory_Callback(hObject, eventdata, handles)
% hObject    handle to Directory (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Directory as text
%        str2double(get(hObject,'String')) returns contents of Directory as a double

end

% --- Executes during object creation, after setting all properties.
function Directory_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Directory (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end


function FileName_Callback(hObject, eventdata, handles)
% hObject    handle to FileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FileName as text
%        str2double(get(hObject,'String')) returns contents of FileName as a double

end

% --- Executes during object creation, after setting all properties.
function FileName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end


% --- Executes on button press in AddSubFrame.
function AddSubFrame_Callback(hObject, eventdata, handles)
% hObject    handle to AddSubFrame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


AddRect(handles);
end


% --- Executes on slider movement.
function FrameSlide_Callback(hObject, eventdata, handles)
% hObject    handle to FrameSlide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
DrawFrame(handles)

end


% --- Executes during object creation, after setting all properties.
function FrameSlide_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FrameSlide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

end


function FrameNum_Callback(hObject, eventdata, handles)
% hObject    handle to FrameNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FrameNum as text
%        str2double(get(hObject,'String')) returns contents of FrameNum as a double
end


% --- Executes during object creation, after setting all properties.
function FrameNum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FrameNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end



function PhaseNum_Callback(hObject, eventdata, handles)
% hObject    handle to PhaseNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PhaseNum as text
%        str2double(get(hObject,'String')) returns contents of PhaseNum as a double
end

% --- Executes during object creation, after setting all properties.
function PhaseNum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PhaseNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6

end


% --- Executes on button press in DelRect.
function DelRect_Callback(hObject, eventdata, handles)
% hObject    handle to DelRect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

z=get(handles.SubFrameNum,'Value');
DelRect(handles,z)
end


% --- Executes on selection change in SubFrameNum.
function SubFrameNum_Callback(hObject, eventdata, handles)
% hObject    handle to SubFrameNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns SubFrameNum contents as cell array
%        contents{get(hObject,'Value')} returns selected item from SubFrameNum

i=get(hObject,'Value');
ImageCrop=get(gcf,'UserData');
IC=ImageCrop.PosMat;
setrectposition(handles,IC(i,:));

end

% --- Executes during object creation, after setting all properties.
function SubFrameNum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SubFrameNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




end

function SubFramesDir_Callback(hObject, eventdata, handles)
% hObject    handle to SubFramesDir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SubFramesDir as text
%        str2double(get(hObject,'String')) returns contents of SubFramesDir as a double

end

% --- Executes during object creation, after setting all properties.
function SubFramesDir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SubFramesDir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end

% --- Executes on button press in GetFrames.
function GetFrames_Callback(hObject, eventdata, handles)
% hObject    handle to GetFrames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%function initiate_figure(handles)
% set(handles.Directory,'string','Z:\Sporulation\102805 - Three colors movie');
% set(handles.FileName,'string','102805tricolor-02');
% set(handles.PhaseNum,'string','2');
% destinationd='CFP:\Documents and Settings\Avigdor Eldar\Desktop\sporula\small'
% pn=1 ;
% nm=-1;

directory=get(handles.Directory,'string');
if directory(end)~='\';
    directory=[directory,'\'];
end

filename=get(handles.FileName,'string');
phasenum=str2double(get(handles.PhaseNum,'string'));
MaskName=[directory,filename];
SubFramesDir=get(handles.SubFramesDir,'string');
flag=0;
if exist([MaskName,'.mat'])==2
    button = questdlg('A mat file was already created, do you want to continue?','');
    switch button
        case('No')

        case('Cancel')
            return
        case('')
            return
        case('Yes');
            flag=1;
    end
else
    flag=1;
end
if flag==1
    ImageCrop.MaskName=filename;
    ImageCrop.directory=directory;
    ImageCrop.SubFramesDir=SubFramesDir;
    %ImageCrop.SubFrameDir=directory;'CFP:\My Works\Sporulation\Movies\102805-Three colors';
    %ImageCrop.SubFrameDir='CFP:\My Works\Sporulation\Movies\102805-Three colors cont';
    %set(handles.SubFramesDir,'String',ImageCrop.SubFramesDir);
    ImageCrop.PhaseNum=phasenum;

    mainphase=ceil((phasenum+1)/2);
    if get(handles.SingleFile,'value')==0
        [name,indx]=makename(directory,filename,'p',phasenum,'*',phasenum,0);
        lst=dir(name);
        N=length(lst);
        set(handles.display,'String',['there are ',num2str(N),' files in the pattern'])
        
        fnum = zeros(1,N);
        for i=1:N
            fname(i,:)=lst(i).name;
            fnum(i)=str2double(fname(i,end-6:end-4));
        end
    else
        [allfile,indx]=makename(directory,filename,'p',phasenum,'*',phasenum,1);
        if exist(allfile)==2
            N=length(imfinfo(allfile));
            fname=allfile;
            fnum=0:N-1;
        else
            disp(['no single file with the name: ', allfile]);
            return
        end
    end

    ImageCrop.N=N;
    ImageCrop.PosMat=zeros(0,4);
    ImageCrop.Mask=cell(0);
    ImageCrop.fname=fname;
    ImageCrop.fnum=fnum;

    if get(handles.SingleFile,'value')==0
        A=imread([ImageCrop.directory,ImageCrop.fname(1,:)]);
    else
        A=imread([ImageCrop.fname],1);
    end
    ImageCrop.phasesize=size(A);
    set(gcf,'UserData',ImageCrop);

    set(handles.FrameSlide,'Min',1);
    set(handles.FrameSlide,'Max',N);
    set(handles.FrameSlide,'SliderStep',[1/N 10/N]);

    set(handles.FrameSlide,'Value',ceil(N/2));
    DrawFrame(handles)

end
end

function DrawFrame(handles);


ImageCrop=get(gcf,'UserData');

FrameNum=round(get(handles.FrameSlide,'Value'));
axes(handles.axes1)

if get(handles.SingleFile,'value')==0

    clr=get(handles.displayColor,'String');
    for i=1:length(clr)
        filename=get(handles.FileName,'string');
        phasenum=str2double(get(handles.PhaseNum,'string'));
        if clr(i)~='p';
            phasenum=1;
        end
        [name,indx]=makename(ImageCrop.directory,filename,clr(i),phasenum,ImageCrop.fnum(FrameNum));
        A{i}=imread(name,'tif');
        res=ImageCrop.phasesize(1)/size(A{i},1);
        if res~=1
            A{i}=imresize(A{i},res);
        end
    end
    set(handles.DispFrame,'String',['Displayed file: ',ImageCrop.fname(FrameNum,:)]);
else
    fullfile=ImageCrop.fname;
    A{1}=imread(fullfile,'tif',FrameNum);

    set(handles.DispFrame,'String',['Displayed file: ',ImageCrop.fname, ' index=',num2str(FrameNum)]);
end

%imagesc(A)
lA=length(A)
switch lA
    case 1
        imrgb(A{1});
    case 2
        imrgb(A{1},A{2});
    case 3
        imrgb(A{1},A{2},A{3});
end
colormap('gray');
set(gca,'xticklabel',[]);
set(gca,'yticklabel',[]);


DrawRect(handles)

end

function setrectposition(handles,c);
set(handles.X,'String',num2str(c(1)));
set(handles.Y,'String',num2str(c(2)));
set(handles.dX,'String',num2str(c(3)));
set(handles.dY,'String',num2str(c(4)));

end

function c=getrectposition(handles);
c(1)=str2num(get(handles.X,'String'));
c(2)=str2num(get(handles.Y,'String'));
c(3)=str2num(get(handles.dX,'String'));
c(4)=str2num(get(handles.dY,'String'));
end
    
function DrawRect(handles,range);

ImageCrop=get(gcf,'UserData');
IC=ImageCrop.PosMat;
MO=ImageCrop.Mask;
if nargin==1
    range=1:size(IC,1);
end
axes(handles.axes1)
hold on

for i=range
    c=IC(i,:);
    %     Lx=[c(1) c(1) c(1)+c(3) c(1)+c(3) c(1)];
    %     Ly=[c(2) c(2)+c(4) c(2)+c(4) c(2) c(2)];
    Lx=MO{i}(1,:);
    Ly=MO{i}(2,:);
    Tp=[c(1)+c(3)/2 c(2)+c(4)/2];
    L=line(Lx,Ly);
    set(L,'color','y');
    t=text(Tp(1),Tp(2),num2str(i));
    set(t,'fontsize',16,'color','y','FontWeight','Bold');
end
end

function AddRect(handles)

axes(handles.axes1);
xs=get(handles.axes1,'xlim');
ys=get(handles.axes1,'ylim');
[x,y,BW,xi,yi] = roipoly;

minx=ceil(round(max(min(xi),0)/2)*2)-1;
miny=ceil(round(max(min(yi),0)/2)*2)-1;

maxx=ceil(round(min(max(xi),floor(xs(2))))/2)*2;
maxy=ceil(round(min(max(yi),floor(ys(2))))/2)*2;
c=[minx miny (maxx-minx) (maxy-miny)]

ImageCrop=get(gcf,'UserData');
IC=ImageCrop.PosMat;
IC(end+1,:)=c;

IM=ImageCrop.Mask;
IM{end+1}=[xi';yi'];

ImageCrop.PosMat=IC;
ImageCrop.Mask=IM;

set(gcf,'UserData',ImageCrop);

DrawRect(handles);
setrectposition(handles,IC(end,:));

set(handles.SubFrameNum,'String',mat2cell(1:size(IC,1)));
set(handles.SubFrameNum,'Value',size(IC,1));
end
% function AddRect(handles)
%
% axes(handles.axes1);
% xs=get(handles.axes1,'xlim')
% ys=get(handles.axes1,'ylim')
%
% key = waitforbuttonpress;
% if key==0
%
%     point1 = get(gca,'CurrentPoint');    % button down detected
%     finalRect = rbbox;                   % return figure units
%     point2 = get(gca,'CurrentPoint');    % button up detected
%     point(1,:) = point1(1,1:2);              % extract x and y
%     point(2,:) = point2(1,1:2);
%
%     minx=ceil(round(max(min(point(:,1)),1))/2)*2-1;
%     miny=ceil(round(max(min(point(:,2)),1))/2)*2-1;
%
%     maxx=ceil(round(min(max(point(:,1)),floor(xs(2))))/2)*2;
%     maxy=ceil(round(min(max(point(:,2)),floor(ys(2))))/2)*2;
%
%     c=[minx miny (maxx-minx) (maxy-miny)]
%
% end
%
% ImageCrop=get(gcf,'UserData');
% IC=ImageCrop.PosMat;
% IC(end+1,:)=c;
% ImageCrop.PosMat=IC;
%
% set(gcf,'UserData',ImageCrop);
%
% DrawRect(handles);
% setrectposition(handles,IC(end,:));
%
% set(handles.SubFrameNum,'String',mat2cell(1:size(IC,1)));
% set(handles.SubFrameNum,'Value',size(IC,1));
% end

function DelRect(handles,z)

ImageCrop=get(gcf,'UserData');
IC=ImageCrop.PosMat;
MO=ImageCrop.Mask;
[m,n]=size(IC);
if m>1
    IO(1:(m-1),1:4)=IC([1:z-1 z+1:m],:);
    MO=MO([1:z-1 z+1:m]);
else
    IO=zeros(0,n);
    MO=cell(0);
end

ImageCrop.PosMat=IO;
ImageCrop.Mask=MO;

set(gcf,'UserData',ImageCrop);

if m>1
    set(handles.SubFrameNum,'String',1:size(IO,1));
    set(handles.SubFrameNum,'Value',size(IO,1));
else
    set(handles.SubFrameNum,'String',{''});
    set(handles.SubFrameNum,'Value',1);
end

DrawFrame(handles);
end

% --- Executes on button press in MakeSubFrames.
function MakeSubFrames_Callback(hObject, eventdata, handles)
% hObject    handle to MakeSubFrames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

button = questdlg('Do you realy want to make the subframes?','','Yes','No','Cancel','No');
switch button
    case('Yes')
        ImageCrop=get(gcf,'UserData');
        pn=ImageCrop.PhaseNum;
        c=ImageCrop.PosMat;
        maskname=ImageCrop.MaskName;
        directory=ImageCrop.directory;
        MO=ImageCrop.Mask;



        SubFramesDir=get(handles.SubFramesDir,'String');
        ImageCrop.SubFrameDir=SubFramesDir;
        if exist(SubFramesDir)~=7
            mkdir(SubFramesDir);
        end



        SingleFile=get(handles.SingleFile,'value');
        clr='cgyrtx';

        for j=1:6
            [clrname,indx]=makename(directory,maskname,clr(j),1,'*',1,SingleFile);
            clrlist=dir(clrname);
            if length(clrlist)>0
                clrflag(j)=1;
            else
                clrflag(j)=0;
            end
        end
        existclr=find(clrflag==1);
        ImageCrop.ColorList=clr(existclr);

        %phase images
        FileRange=ImageCrop.fnum+1;
        InputRange=str2num(get(handles.FrameRange,'string'));
        if ~isempty(InputRange)
            FileRange=FileRange(find(FileRange>=min(InputRange) & FileRange<=max(InputRange)));
        end
        for j=FileRange

            for i=1:pn


                [pname,indx]=makename(directory,maskname,'p',i,j,pn,SingleFile,0);
                clear A
                try
                    A=imread(pname,'tif',indx);
                    info=imfinfo(pname,'tif');
                    try
                        description=info(indx).ImageDescription;
                    catch
                        description='';
                    end
                    psize=size(A);
                    for k=1:size(c,1)
                        [newpname,indx]=makename(SubFramesDir,maskname,'p',i,j,pn,0,0,[],k);
                        B=A(c(k,2):c(k,2)+c(k,4),c(k,1):c(k,1)+c(k,3));
                        subdesc=[description,' subframed to positions: [',num2str(c(k,:)),']'];
                        imwrite(B,newpname,'tif','description',subdesc);
                        disp(['saving: ',newpname]);
                    end
                catch
                    disp([pname, ' does not exist']);
                end
            end
            psize=size(A);
            %mask
            if j==ImageCrop.fnum(1)+1
                for k=1:size(c,1)
                    newMname=[SubFramesDir,'\',maskname,'_',num2str(k),'-mask.tif'];%,'%5.2d')
                    Mask=roipoly(A,MO{k}(1,:),MO{k}(2,:));
                    subMask=Mask(c(k,2):c(k,2)+c(k,4),c(k,1):c(k,1)+c(k,3));
                    imwrite(subMask,newMname,'tif','description',subdesc);
                end
            end

            for t=existclr
                [name,indx]=makename(directory,maskname,clr(t),1,j,1,SingleFile,0);
                clear A;
                try

                    A=imread(name,'tif',indx);
                    info=imfinfo(name,'tif');
                    try
                        description=info(indx).ImageDescription;
                    catch
                        description='';
                    end
                    res=psize(1)/size(A,1); %res is usually 1 or 2
                    %A=imresize(A,res);
                    d=[ceil(c(:,[1 2])/res) floor((c(:,[3 4])/res))];
                    for k=1:size(c,1)
                        [newcname,indx]=makename(SubFramesDir,maskname,clr(t),1,j,1,0,0,[],k);
                        B=A(d(k,2):d(k,2)+d(k,4),d(k,1):d(k,1)+d(k,3));;
                        subdesc=[description,' subframed to positions: [',num2str(d(k,:)),'] resized frame by a factor: ',num2str(res)];
                        imwrite(B,newcname,'tif','description',subdesc);
                        disp(['saving: ',newcname]);
                    end
                catch
                    disp([name, ' does not exist']);
                end
            end

        end
        datafile1=[SubFramesDir,maskname];
        %datafile2=[fn];
        save(datafile1,'ImageCrop');
        %save(datafile2,'ImageCrop');
end
end

function [name,indx]=makename(dir,mask,color,znum,frame,zmaxnum,flag,firstframe,posnum,subposnum);

if nargin<6
    zmaxnum=znum;
end
if nargin<7
    flag=0;
end
if nargin<8
    if flag==0
        firstframe=0;
    else
        firstframe=1;
    end
end
if nargin<9
    posnum=[];
end
if nargin<10
    subposnum=[];
end

if ~isempty(posnum)
    posmask=['-',num2str(posnum,'%5.2d'),'-'];
else
    posmask=[];
end

if ~isempty(subposnum)
    subposmask=['_',num2str(subposnum)];
else
    subposmask=[];
end


if dir(end)~='\'
    dir=[dir,'\'];
end

if flag==0
    indx=1;
    if isnumeric(frame)
        fnum=str3(frame-firstframe-1);
    else
        fnum=frame;
    end

    if zmaxnum==1
        name=[dir,mask,subposmask,posmask,'-',color,'-',fnum,'.tif'];
    else
        name=[dir,mask,subposmask,posmask,'-',color,'-',num2str(znum),'-',fnum,'.tif'];
    end
else
    indx=frame-firstframe;
    if zmaxnum==1
        name=[dir,mask,subposmask,posmask,'-',color,'-all.tif'];
    else
        name=[dir,mask,subposmask,posmask,'-',color,'-',num2str(znum),'-all.tif'];
    end
end
end
% --- Executes on button press in SingleFile.
function SingleFile_Callback(hObject, eventdata, handles)
% hObject    handle to SingleFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of SingleFile

end




function displayColor_Callback(hObject, eventdata, handles)
% hObject    handle to displayColor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of displayColor as text
%        str2double(get(hObject,'String')) returns contents of displayColor as a double
end

% --- Executes during object creation, after setting all properties.
function displayColor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to displayColor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end


% --- Executes on button press in MarkPoints.
function MarkPoints_Callback(hObject, eventdata, handles)
% hObject    handle to MarkPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.MarkPoints,'value')
    %     set(handles.axes1,'WindowButtonMotionFcn',['global pos Limage ourfig res pp phfig;pos=max(1,round((1/res)*get(gca,''CurrentPoint'')));',...
    %         'if (pos(1,2)>0 & pos(1,2)<size(Limage,1) & pos(1,1)>0 & pos(1,1)<size(Limage,2));',...
    %         'curr_val=num2str(double(Limage(pos(1,2),pos(1,1))));else;curr_val=''-1'';end;',...
    %         'set(ourfig,''name'',[''Pos: '',num2str(pos(1,2)),'' , '',num2str(pos(1,1)),',...
    %         '''  Val: '',curr_val]);']);
    set(handles.axes1,'WindowButtonMotionFcn',['global pos ;pos=get(gca,''CurrentPoint'')));'])
else
    set(handles.axes1,'WindowButtonMotionFcn','');

end
end

function AddPointFunction
global pos Limage ourfig res pp phfig
if get(handles.MarkPoints,'value')

    axes(handles.axes1)
    hold on
    plot(pos(2),pos(1),'+')
end

end

function FrameRange_Callback(hObject, eventdata, handles)
% hObject    handle to FrameRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FrameRange as text
%        str2double(get(hObject,'String')) returns contents of FrameRange as a double

end
% --- Executes during object creation, after setting all properties.
function FrameRange_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FrameRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end
