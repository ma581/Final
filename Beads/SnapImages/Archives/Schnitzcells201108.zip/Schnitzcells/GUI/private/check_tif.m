

function ok = check_tif(filename)
% return T if a .TIF file
% ok = 0;
[d,n,e] = fileparts(filename);
ok = ~isempty(n) && strncmpi('.tif',e,4);

