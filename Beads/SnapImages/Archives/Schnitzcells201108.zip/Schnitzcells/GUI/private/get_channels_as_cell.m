


function ach = get_channels_as_cell(tifs,movname)
% return the channels in a cell array
m = regexp(tifs,[movname '\-[\w]+\-'],'match');
a = unique([m{:}]);
ach = strrep(a,movname,'');


