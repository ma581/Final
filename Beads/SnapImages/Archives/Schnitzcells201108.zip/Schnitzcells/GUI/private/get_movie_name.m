



function mname = get_movie_name(frame)
mname = '';
a = strfind(frame,'-');
if numel(a)~=3
    return
end
mname = frame(1:a(2)-1);



