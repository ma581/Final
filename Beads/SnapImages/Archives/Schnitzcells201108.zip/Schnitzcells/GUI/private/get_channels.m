


function msg = get_channels(tifs,movname)
% return number of channels for each movie name as msgbox text 
m = regexp(tifs,[movname '\-[\w]+\-'],'match');
a = unique([m{:}]);
msg = [sprintf('Movie %s:\n\n',movname)];
for i=1:length(a)
    msg = [msg sprintf('Channel %s has %d frames.\n', ...
        strrep(a{i},movname,''), length(cell2mat(regexp(tifs,a{i}))) )];
end



