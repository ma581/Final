

function tifs = get_tif_files(folder)
files = dir(folder);
files = files(cellfun(@check_tif,{files(:).name}));
tifnames = struct2cell(files(:));
tifnames = tifnames(1,:)';
tifs = tifnames;
