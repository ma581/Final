


function ok = check_end_frame
ok = 0;
endframe = str2double(get(findobj('tag','edit_frame'),'string'));
h = get(findobj('tag','segment_figure'),'userdata');
if isnan(endframe) || endframe > h.num_frames
    msgbox('Invalid frame number.','Schnitzcells','error','modal');
    uicontrol(findobj('tag','edit_frame'));
else
    ok = 1;
end

