

function ic = get_png_icon(iconfile)
ic = mat2gray(imread(iconfile));
ic(ic(:,:,1)+ic(:,:,2)+ic(:,:,3)==0) = NaN;     % transparency




