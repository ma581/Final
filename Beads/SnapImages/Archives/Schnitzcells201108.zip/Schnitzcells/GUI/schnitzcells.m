

function schnitzcells
% main SCHNITZCELLS window 

% raise the running figure if there is one
fig = findall(0,'tag','schnitzcells_figure');
if ~isempty(fig)
    figure(fig);
else
    setup_schnitzcells_figure;
end


%-----------------------------------------------------------------
% setup main figure
%-----------------------------------------------------------------
function setup_schnitzcells_figure

fig = figure('numbertitle','off',...
    'name','SCHNITZCELLS',...
    'dock','off',...
    'menubar','none',...
    'handlevisibility','off',...
    'toolbar','none',...
    'resize','off',...
    'tag','schnitzcells_figure',...
    'color',[0.7 0.7 0.7],...
    'closerequest',@shut_down,...
    'keypressfcn',@main_esc_handler_callback,...
    'visible','off');

% position to the middle of screen
mp = get(0,'monitorpos');
set(fig,'pos',[(mp(3)-480)/2 (mp(4)-100)/2 500 110]);


% create buttons
button_init = uicontrol(fig,'style','push',...
    'string','Initialize',...
    'pos',[10 60 100 40],...
    'keypress',@main_esc_handler_callback,...
    'callback',@button_init_callback);

button_segment = uicontrol(fig,'style','push',...
    'string','Segment',...
    'pos',[120 60 100 40],...
    'keypress',@main_esc_handler_callback,...
    'callback',@button_segment_callback);

button_track = uicontrol(fig,'style','push',...
    'string','Track',...
    'pos',[230 60 100 40],...
    'keypress',@main_esc_handler_callback,...
    'callback',@button_track_callback);

button_plot = uicontrol(fig,'style','push',...
    'string','Plot',...
    'pos',[340 60 100 40],...
    'keypress',@main_esc_handler_callback,...    
    'callback',@button_plot_callback);

edit_work_folder = uicontrol(fig,'style','edit',...
    'tag','edit_work_folder',...
    'backgroundcolor',[0.7 0.7 0.7],...
    'horizontal','left',...
    'pos',[10 10 480 40],...
    'keypress',@main_esc_handler_callback,...
    'enable','inactive');

button_help = uicontrol(fig,'style','push',...
    'cdata',get_png_icon(['private' filesep 'help_icon.png']),...
    'pos',[450 60 40 40],...
    'keypress',@main_esc_handler_callback,...
    'callback',@button_help_callback);

% cancel zoom mode if a key is pressed
% addlistener(fig,'WindowKeyPress',@cancel_zoom_mode);

handles.p = [];
handles.channels = [];
handles.num_frames = [];
set(fig,'userdata',handles);
set(fig,'visible','on');


%-----------------------------------------------------------------
% setup initialization figure
%-----------------------------------------------------------------
function setup_schinit_figure

fig = figure('numbertitle','off',...
    'name','SCHNITZCELLS - INITIALIZATION',...
    'dock','off',...
    'menubar','none',...
    'handlevisibility','off',...
    'toolbar','none',...
    'resize','off',...
    'tag','schinit_figure',...
    'color',[0.7 0.7 0.7],...
    'closerequest',@close_schinit_figure,...
    'keypressfcn',@schinit_esc_handler_callback,...
    'visible','off');

mainfig = findall(0,'tag','schnitzcells_figure');
% position the figure
mfpos = get(mainfig,'position');
set(fig,'position',[mfpos(1)-50 mfpos(2)-200 600 280]);

% uicontrols
button_image_folder = uicontrol(fig,'style','push',...
    'tag','button_image_folder',...
    'pos',[10 240 100 32],...
    'string','Image folder',...
    'keypress',@schinit_esc_handler_callback,...
    'callback',@button_image_folder_callback);
    
edit_image_folder = uicontrol(fig,'style','edit',...
    'tag','edit_image_folder',...
    'pos',[110 240 480 32],...
    'background',[0.7 0.7 0.7],...
    'horizontal','left',...
    'enable','inactive',...
    'keypress',@schinit_esc_handler_callback,...
    'string',blanks(0));

text_kind = uicontrol(fig,'style','text',...
    'pos',[280 215 32 16],...
    'string','Kind ');

text_movie = uicontrol(fig,'style','text',...
    'pos',[20 215 42 16],...
    'string','Movie');

text_date = uicontrol(fig,'style','text',...
    'pos',[437 215 33 16],...
    'string','Date');

popup_movie = uicontrol(fig,'style','popup',...
    'tag','popup_movie',...
    'pos',[70 210 200 24],...
    'callback',@popup_movie_callback,...
    'keypress',@schinit_esc_handler_callback,...
    'string','Select movie',...
    'value',1);
    
edit_movie_date = uicontrol(fig,'style','edit',...
    'tag','edit_movie_date',...
    'pos',[480 208 110 32],...
    'horizontal','left',...
    'callback',@edit_movie_date_callback,...
    'background',[0.7 0.7 0.7],...
    'keypress',@schinit_esc_handler_callback,...    
    'string',blanks(0));
    
popup_kind = uicontrol(fig,'style','popup',...
    'tag','popup_movie_kind',...
    'pos',[312 210 120 24],...
    'callback',@popup_kind_callback,...
    'string',{'Bacillus';'E.Coli'},...
    'keypress',@schinit_esc_handler_callback,...
    'value',1);

button_analysis_folder = uicontrol(fig,'style','push',...
    'pos',[10 178 100 32],...
    'string','Analysis folder',...
    'keypress',@schinit_esc_handler_callback,...
    'callback',@button_analysis_folder_callback);

edit_analysis_folder = uicontrol(fig,'style','edit',...
    'pos',[110 178 480 32],...
    'tag','edit_analysis_folder',...
    'callback',@edit_analysis_folder_callback,...
    'horizontal','left',...
    'background',[0.7 0.7 0.7],...
    'keypress',@schinit_esc_handler_callback,...
    'enable','inactive',...
    'string',blanks(0));

button_load = uicontrol(fig,'style','push',...
    'pos',[10 140 100 32],...
    'string','Load',...
    'keypress',@schinit_esc_handler_callback,...    
    'callback',@button_load_callback);

button_save = uicontrol(fig,'style','push',...
    'pos',[120 140 100 32],...
    'string','Save',...
    'keypress',@schinit_esc_handler_callback,...
    'callback',@button_save_callback);

button_schinit = uicontrol(fig,'style','push',...
    'tag','button_schinit',...
    'pos',[380 140 100 32],...
    'string','Initialize',...
    'keypress',@schinit_esc_handler_callback,...
    'callback',@button_schinit_callback);

button_cancel = uicontrol(fig,'style','push',...
    'pos',[490 140 100 32],...
    'string','Cancel',...
    'keypress',@schinit_esc_handler_callback,...
    'callback',@button_cancel_callback);

edit_message = uicontrol(fig,'style','edit',...
    'tag','edit_message',...
    'background',[0.7 0.7 0.7],...
    'horizontal','left',...
    'enable','inactive',...
    'max',2,...
    'keypress',@schinit_esc_handler_callback,...
    'pos',[10 10 580 120]);
    
button_help = uicontrol(fig,'style','push',...
    'cdata',get_png_icon(['private' filesep 'help_icon.png']),...
    'string',blanks(0),...
    'pos',[290 140 32 32],...
    'keypress',@schinit_esc_handler_callback,...
    'callback',@button_help_callback);

handles = get(mainfig,'userdata');
set(fig,'userdata',handles);
set(fig,'visible','on');


%-----------------------------------------------------------------
% setup segment figure
%-----------------------------------------------------------------
function setup_segment_figure

fig = figure('numbertitle','off',...
    'name','SCHNITZCELLS - SEGMENTATION',...
    'dock','off',...
    'menubar','none',...
    'handlevisibility','off',...
    'toolbar','none',...
    'resize','off',...
    'tag','segment_figure',...
    'color',[0.7 0.7 0.7],...
    'closerequest',@close_segment_figure,...
    'keypressfcn',@segment_esc_handler_callback,...
    'visible','off');

% position under main figure
mainfig = findall(0,'tag','schnitzcells_figure');
mfpos = get(mainfig,'position');
set(fig,'position',[mfpos(1)+100 mfpos(2)-140 300 220]);

% create uicontrols
text_channel = uicontrol(fig,'style','text',...
    'pos',[40 180 140 20],...
    'horizontal','left',...
    'string','Segmentation channel');

popup_channel = uicontrol(fig,'style','popup',...
    'pos',[180 175 80 28],...
    'tag','popup_channel',...
    'value',1,...
    'string',blanks(0),...
    'keypress',@segment_esc_handler_callback);

button_test_segmentation = uicontrol(fig,'style','push',...
    'pos',[70 140 150 32],...
    'string','Test segmentation',...
    'keypress',@segment_esc_handler_callback,...
    'callback',@button_test_segment_callback);

text_segment = uicontrol(fig,'style','text',...
    'pos',[40 100 140 20],...
    'horizontal','left',...
    'string','Segment until frame');
    
edit_frame = uicontrol(fig,'style','edit',...
    'tag','edit_frame',...
    'pos',[180 100 80 32],...
    'horizontal','left',...
    'background',[0.7 0.7 0.7],...
    'callback',@edit_frame_callback,...
    'string',blanks(0));

button_segment_frames = uicontrol(fig,'style','push',...
    'pos',[110 60 150 32],...
    'string','Segment all frames',...
    'keypress',@segment_esc_handler_callback,...
    'callback',@button_segment_frames_callback);

button_verify = uicontrol(fig,'style','push',...
    'pos',[110 20 150 32],...
    'string','Verify segmentation',...
    'keypress',@segment_esc_handler_callback,...
    'callback',@button_verify_callback);

button_help = uicontrol(fig,'style','push',...
    'cdata',get_png_icon(['private' filesep 'help_icon.png']),...
    'pos',[40 40 32 32],...
    'keypress',@segment_esc_handler_callback,...
    'callback',@button_help_callback);

h = get(mainfig,'userdata');
handles.p = h.p;
handles.channels = h.channels;
handles.num_frames = h.num_frames;

set(popup_channel,'string',handles.channels);
set(popup_channel,'value',1);
set(edit_frame,'string',handles.num_frames);

set(fig,'userdata',handles);
set(fig,'visible','on');




%-----------------------------------------------------------------
% initialize button
%-----------------------------------------------------------------
function button_init_callback(src,evt)
setup_schinit_figure;

%-----------------------------------------------------------------
% segment button
%-----------------------------------------------------------------
function button_segment_callback(src,evt)
h = get( get(src,'parent') , 'userdata');
if ~isempty(h.p)
    setup_segment_figure;
else
    msgbox('You must initialize a valid folder.','Schnitzcells','error','modal');
end

%-----------------------------------------------------------------
% track button
%-----------------------------------------------------------------
function button_track_callback(src,evt)
h = get( get(src,'parent') , 'userdata');
if ~isempty(h.p)
    setup_track_figure;
else
    msgbox('You must initialize a valid folder.','Schnitzcells','error','modal');
end

%-----------------------------------------------------------------
% plot button
%-----------------------------------------------------------------
function button_plot_callback(src,evt)
h = get( get(src,'parent') , 'userdata');
if ~isempty(h.p)
    setup_plot_figure;
else
    msgbox('You must initialize a valid folder.','Schnitzcells','error','modal');
end

%-----------------------------------------------------------------
% ESC handler
%-----------------------------------------------------------------
function main_esc_handler_callback(src,evt)
if isequal(evt.Key,'escape')
    close(findall(0,'tag','schnitzcells_figure'));
end

%-----------------------------------------------------------------
% help button
%-----------------------------------------------------------------
function button_help_callback(src,evt)
p = get(get(src,'parent'),'tag');
a = 0;
switch p
    case 'schnitzcells_figure'
        a = web('schdoc/index.html', '-browser');
    case 'schinit_figure'
        a = web('schdoc/SchnitzcellsInitialization/index.html', '-browser');
    case 'segment_figure'
        a = web('schdoc/SchnitzcellsSegmentation/index.html', '-browser');
    case 'track_figure'
        a = web('schdoc/SchnitzcellsTracking/index.html', '-browser');
    otherwise
        % disp('Unknown method.')
end
if a > 0
    msgbox('Browser not found, please check schdoc folder manually.','Schnitzcells','error','modal');
end



%-----------------------------------------------------------------
% closes all related figures and exits
%-----------------------------------------------------------------
function shut_down(src,evt)
% verify that shut down is not accidental
a = questdlg('Close ?','SCHNITZCELLS','Yup. Done.','It was an accident.','It was an accident.');
if isequal(a,'Yup. Done.')
    delete(findall(0,'tag','schinit_figure'));
    delete(findall(0,'tag','segment_figure'));
    delete(findall(0,'tag','figtrack'));
    delete(findall(0,'tag','figplot'));
    delete(src);
end


%-----------------------------------------------------------------
% schinit close request handler
%-----------------------------------------------------------------
function close_schinit_figure(src,evt)
% mainfig = findobj('tag','schnitzcells_figure');
% initfig = findobj('tag','schinit_figure');
% h = get(initfig,'userdata');
% set(mainfig,'userdata',h);
delete(findall(0,'tag','schinit_figure'));

%-----------------------------------------------------------------
% schinit ESC handler
%-----------------------------------------------------------------
function schinit_esc_handler_callback(src,evt)
if isequal(evt.Key,'escape')
    set(findall(0,'tag','schnitzcells_figure'),'userdata',[]);
    close(findobj('tag','schinit_figure'));
end

%-----------------------------------------------------------------
% image folder button
%-----------------------------------------------------------------
function button_image_folder_callback(src,evt)
pathstr = uigetdir(pwd,'Select location for image folder');
if isequal(pathstr,0)   % cancelled
    return
end
if ~exist(pathstr,'dir')   % invalid folder
    msgbox('Invalid folder.','Schnitzcells','error','modal');
    uicontrol(findobj('tag','button_image_folder'));
    return
end
set(findobj('tag','edit_image_folder'),'string',[pathstr filesep]);
set(findobj('tag','edit_analysis_folder'),'string',[pathstr filesep]);
% guidata(handles.figinit,handles);
check_image_files;


%-----------------------------------------------------------------
% movie popup
%-----------------------------------------------------------------
function popup_movie_callback(src,evt)
obj = findobj('tag','edit_image_folder');
folder = get(obj,'string');
if ~exist(folder,'dir')
    clear_interface;
    uicontrol(findobj('tag','button_image_folder'));
    return
end
movnames = cellstr(get(findobj('tag','popup_movie'),'string'));
movname = movnames{get(findobj('tag','popup_movie'),'value')};
if isequal(movname,'Select movie')
    return
end
tifs = get_tif_files(folder);
msg = get_channels(tifs,movname);
set(findobj('tag','edit_message'),'string',msg);

%-----------------------------------------------------------------
% movie edit field
%-----------------------------------------------------------------
function edit_movie_date_callback(src,evt)
obj = findobj('tag','edit_movie_date');
movdate = get(obj,'string');
if isempty(movdate)
    msgbox('Movie date cannot be empty.','Schnitzcells','error','modal');
    set(obj,'string',datestr(now,'yyyy-mm-dd'));
    return
end
try
    [y,m,d] = datevec(movdate);
catch
    set(obj,'string',datestr(now,'yyyy-mm-dd'));
    uicontrol(obj);
    return
end
set(obj,'string',datestr([y,m,d,0,0,0],'yyyy-mm-dd'));


%-----------------------------------------------------------------
% movie kind popup
%-----------------------------------------------------------------
function popup_kind_callback(src,evt)

%-----------------------------------------------------------------
% analysis folder button
%-----------------------------------------------------------------
function button_analysis_folder_callback(src,evt)
obj = findobj('tag','edit_analysis_folder');
pathstr = uigetdir(pwd,'Select location for ANALYSIS folder');
if isequal(pathstr,0)   % cancelled
    return
end
if ~exist(pathstr,'dir')
    msgbox('Invalid folder.','Schnitzcells','error','modal');
    return
end
set(obj,'string',[pathstr filesep]);




%-----------------------------------------------------------------
% load button
%-----------------------------------------------------------------
function button_load_callback(src,evt)
% load a previously saved configuration file
[filename, pathname] = uigetfile({'*.mat','Matlab files (*.mat)'},'Select a configuration file');
if isequal(pathname,0) || isequal(filename,0)   % cancel
    return
end
if exist(pathname,'dir') && exist(fullfile(pathname,filesep,filename),'file')
    load(fullfile(pathname,filesep,filename));
else
    msgbox('File not found.','Schnitzcells configuration','warn','modal');
    return
end
if exist('p','var') && ...
    isfield(p,'movieName') && ... 
    isfield(p,'movieDate') && ...
    isfield(p,'movieKind') && ...
    isfield(p,'rootDir') && ...
    isfield(p,'dateDir') && ...
    isfield(p,'movieDir') && ...
    isfield(p,'imageDir') && ...
    isfield(p,'segmentationDir') && ...
    isfield(p,'tracksDir')
    try
        h = get(findall(0,'tag','schinit_figure'),'userdata');
        h.p = p;
        % populate interface
        set(findobj('tag','edit_image_folder'),'string',p.imageDir);
        check_image_files;
        set(findobj('tag','edit_movie_date'),'string',p.movieDate);
        movkinds = cellstr(get(findobj('tag','popup_movie_kind'),'string'));
        movkind = p.movieKind;
        set(findobj('tag','edit_movie_date'),'value',find(strcmp(movkinds,movkind)));
        set(findobj('tag','edit_analysis_folder'),'string',p.rootDir);
    catch
        msgbox('Invalid configuration data.','Schnitzcells','error','modal');
        h.p = [];
    end
else
    msgbox('File does not have configuration data.','Schnitzcells','error','modal');
end
set(findall(0,'tag','schinit_figure'),'userdata',h);
uicontrol(findobj('tag','button_schinit'));



%-----------------------------------------------------------------
% save button
%-----------------------------------------------------------------
function button_save_callback(src,evt)
[filename, pathname] = uiputfile({'*.mat','Matlab files (*.mat)'},'Save configuration');
if isequal(pathname,0) || isequal(filename,0)   % cancel
    return
else
    p = verify_init_data;
    if ~isempty(p)
        save(fullfile(pathname,filesep,filename),'p');
    end
end



%-----------------------------------------------------------------
% initialize button
%-----------------------------------------------------------------
function button_schinit_callback(src,evt)
% initialize p and store in mainfig -> userdata
p = verify_init_data;
if isempty(p)
    msgbox('Cannot verify initialization. Please check folders and images.','Schnitzcells','error','modal');
    return
end

tifs = get_tif_files(p.imageDir);
movnameobj = findobj('tag','popup_movie');
movnames = cellstr(get(movnameobj,'string'));
movname = movnames{get(movnameobj,'value')};
ch = get_channels_as_cell(tifs,movname);

try
    if ~isequal(exist('initschnitz','file'),2)
        msgbox('Cannot locate INITSCHNITZ.M, is the PATH set correctly?','Schnitzcells','error','modal');
        return
    end
    ip = initschnitz(p.movieName,p.movieDate,p.movieKind,'rootDir',p.rootDir,'imageDir',p.imageDir);
    h = get(findall(0,'tag','schnitzcells_figure'),'userdata');
    set(findobj('tag','edit_work_folder'),'string',['Initialized : ',fullfile(p.rootDir,filesep,p.movieDate)]);
    h.p = ip;
    h.channels = ch;
    f = dir([h.p.imageDir,filesep,'*',h.channels{1},'*']);
    if isempty(f)
        msgbox('Image frames not found. Please verify and reinitialize.','Schnitzcells','error','modal');
        return
    end
    h.num_frames = length(f);
    set(findall(0,'tag','schnitzcells_figure'),'userdata',h);
    assignin('base','p',p);
    
    initstr = ['p = initschnitz(''' p.movieName ''',''' p.movieDate ''',''' p.movieKind ''',''rootDir'',''' p.rootDir ''',''imageDir'',''' p.imageDir ''');'];
    
    assignin('base','init',initstr);
    fprintf(1,'\n%s\n\n',initstr);
    disp(p);
    fprintf(1,'\n\n',initstr);
    
    close(findall(0,'tag','schinit_figure'));
catch
    h.p = [];
    msgbox(lasterr,'Schnitzcells','error','modal'),
end


%-----------------------------------------------------------------
% cancel button
%-----------------------------------------------------------------
function button_cancel_callback(src,evt)
close(findall(0,'tag','schinit_figure'));


%-----------------------------------------------------------------
% reset interface 
%-----------------------------------------------------------------
function clear_interface
set(findobj('tag','edit_message'),'string','');
set(findobj('tag','popup_movie'),'string',{'Select movie'});
% set(handles.popup_movie_name,'string',{'Select movie'});







%-----------------------------------------------------------------
% verify tif images
%-----------------------------------------------------------------
function check_image_files
folder = get(findobj('tag','edit_image_folder'),'string');
if ~exist(folder,'dir')
    clear_interface;
    uicontrol(findobj('tag','button_image_folder'));
    return
end
tifs = get_tif_files(folder);
movnames = cellfun(@get_movie_name,tifs,'uniform',false);
movienames = unique(movnames);
if numel(movienames)>=1
    set(findobj('tag','popup_movie'),'string',movienames);
    set(findobj('tag','edit_movie_date'),'string',datestr(now,'yyyy-mm-dd'));
    msg = get_channels(tifs,movienames{1});
    set(findobj('tag','edit_message'),'string',msg);
end

%-----------------------------------------------------------------
% verify init configuration
%-----------------------------------------------------------------
function p = verify_init_data
% called by INIT or SAVE buttons, returns p if verified, or [] if not
p = [];
image_folder = get(findobj('tag','edit_image_folder'),'string');
uicontrol(findobj('tag','button_image_folder'));
if isempty(image_folder) || ~exist(image_folder,'dir')
    clear_interface;
    return
end
movpopup = findobj('tag','popup_movie');
movnames = cellstr(get(movpopup,'string'));
movname = movnames{get(movpopup,'value')};
if isequal(movname,'Select movie')
    return
end
movdateobj = findobj('tag','edit_movie_date');
movdate = get(movdateobj,'string');
if isempty(movdate)
    return
end
analysisfolderobj = findobj('tag','edit_analysis_folder');
analysis_folder = get(analysisfolderobj,'string');
if ~isempty(analysis_folder) && ~exist(analysis_folder,'dir')
    return
elseif isempty(analysis_folder)
    analysis_folder = image_folder;
end

% a sample run
% p = initschnitz(['DelytvaEthanol-14'],'2010-11-15','bacillus','rootDir','C:\Users\alphan\Desktop\jon\data','imageDir','C:\Users\alphan\Desktop\jon\data');
% p
%           movieName: 'DelytvaEthanol-14'
%           movieDate: '2010-11-15'
%           movieKind: 'bacillus'
%             rootDir: 'C:\Users\alphan\Desktop\jon\data\'
%             dateDir: 'C:\Users\alphan\Desktop\jon\data\2010-11-15\'
%            movieDir: 'C:\Users\alphan\Desktop\jon\data\2010-11-15\DelytvaEthanol-14\'
%            imageDir: 'C:\Users\alphan\Desktop\jon\data\'
%     segmentationDir: 'C:\Users\alphan\Desktop\jon\data\2010-11-15\DelytvaEthanol-14\segmentation\'
%           tracksDir: 'C:\Users\alphan\Desktop\jon\data\2010-11-15\DelytvaEthanol-14\data\'

p.movieName = movname;
p.movieDate = movdate;
movkindobj = findobj('tag','popup_movie_kind');
movkinds = cellstr(get(movkindobj,'string'));
p.movieKind = movkinds{get(movkindobj,'value')};
if ~isequal(filesep,analysis_folder(end))
    analysis_folder = [analysis_folder filesep];
end
p.rootDir = analysis_folder;
p.dateDir = [analysis_folder movdate filesep];
p.movieDir = [analysis_folder movdate filesep movname filesep];
p.imageDir = image_folder;
p.segmentationDir = [analysis_folder movdate filesep movname filesep 'segmentation' filesep];
p.tracksDir = [analysis_folder movdate filesep movname filesep 'data' filesep];







%-----------------------------------------------------------------
% close request for segment figure
%-----------------------------------------------------------------
function close_segment_figure(src,evt)
delete(findall(0,'tag','segment_figure'));


%-----------------------------------------------------------------
% ESC handler for segment figure
%-----------------------------------------------------------------
function segment_esc_handler_callback(src,evt)
if isequal(evt.Key,'escape')
    set(findall(0,'tag','schnitzcells_figure'),'userdata',[]);
    close(findall(0,'tag','segment_figure'));
end


%-----------------------------------------------------------------
% test segmentation
%-----------------------------------------------------------------
function button_test_segment_callback(src,evt)
if ~check_end_frame
    return
end
h = get(findall(0,'tag','segment_figure'),'userdata');
if isempty(h.p)
    msgbox('Please initialize a valid folder.','Schnitzcells','error','modal');
    return
end
chid = h.channels{get(findobj('tag','popup_channel'),'value')};
[fn,pn] = uigetfile([h.p.imageDir,'*',chid,'*.tif'],'Select a file to segment');
if isequal(pn,0) || isequal(fn,0)   % cancel
    return
end
k = strfind(fn,chid);
test_frame = str2double( fn(k+3:end-4) );
h.p.testrun = 1;
% segmenter displays images
fig = figure('visible','off');
p = segmoviefluor(h.p,'segrange',[test_frame]);
% for test segmentation we do not update the P structure
set(fig,'visible','on','numbertitle','off','name',fn);


%-----------------------------------------------------------------
% edit end frame to segment
%-----------------------------------------------------------------
function edit_frame_callback(src,evt)
check_end_frame;


%-----------------------------------------------------------------
% segmentation callback
%-----------------------------------------------------------------
function button_segment_frames_callback(src,evt)
if ~check_end_frame
    return
end
h = get(findall(0,'tag','segment_figure'),'userdata');
try
    fig = figure('visible','off','numbertitle','off');
    sr = str2double(get(findobj('tag','edit_frame'),'string'));
    h.p = segmoviefluor(h.p,'segrange',[1:sr]);
    drawnow;
    set(fig,'visible','on');
    set(findall(0,'tag','segment_figure'),'userdata',h);
    set(findall(0,'tag','schnitzcells_figure'),'userdata',h);
catch
    msg = lasterr;
    msgbox(msg,'Segmentation BOO-BOO','error');
end


%-----------------------------------------------------------------
% manual verification callback
%-----------------------------------------------------------------
function button_verify_callback(src,evt)
if ~check_end_frame
    return
end
h = get(findall(0,'tag','segment_figure'),'userdata');
try
    h.p = manualcheckseg(h.p,'override',1);
    set(findall(0,'tag','segment_figure'),'userdata',h);
    set(findall(0,'tag','schnitzcells_figure'),'userdata',h);
catch
    msg = lasterr;
    msgbox(msg,'Verification BOO-BOO','error');
end









%-----------------------------------------------------------------
% setup track figure
%-----------------------------------------------------------------
function setup_track_figure

fig = figure('numbertitle','off',...
    'name','SCHNITZCELLS - TRACKING',...
    'dock','off',...
    'menubar','none',...
    'handlevisibility','off',...
    'toolbar','none',...
    'resize','off',...
    'tag','track_figure',...
    'color',[0.7 0.7 0.7],...
    'closerequest',@close_track_figure,...
    'keypressfcn',@track_esc_handler_callback,...
    'visible','off');

% position under main figure
mainfig = findall(0,'tag','schnitzcells_figure');
mfpos = get(mainfig,'position');
set(fig,'position',[mfpos(1)+100 mfpos(2)-140 250 130]);

% create uicontrols
check_overwrite = uicontrol(fig,'style','check',...
    'pos',[40 90 200 24],...
    'string','Overwrite previous tracking',...
    'keypress',@track_esc_handler_callback,...
    'tag','check_overwrite');

button_track_callback = uicontrol(fig,'style','push',...
    'pos',[80 50 150 34],...
    'string','Track all frames',...
    'keypress',@track_esc_handler_callback,...
    'callback',@button_schtrack_callback);

button_verify_track = uicontrol(fig,'style','push',...
    'pos',[80 10 150 34],...
    'string','Verify tracking',...
    'keypress',@track_esc_handler_callback,...
    'callback',@button_verify_track_callback);

button_help = uicontrol(fig,'style','push',...
    'cdata',get_png_icon(['private' filesep 'help_icon.png']),...
    'pos',[30 30 40 40],...
    'keypress',@track_esc_handler_callback,...
    'callback',@button_help_callback);




h = get(mainfig,'userdata');
handles.p = h.p;
handles.channels = h.channels;
handles.num_frames = h.num_frames;

set(fig,'userdata',handles);
set(fig,'visible','on');


%-----------------------------------------------------------------
% close request for track figure
%-----------------------------------------------------------------
function close_track_figure(src,evt)
delete(findall(0,'tag','track_figure'));

%-----------------------------------------------------------------
% button track callback
%-----------------------------------------------------------------
function button_schtrack_callback(src,evt)
mainfig = findall(0,'tag','schnitzcells_figure');
h = get(mainfig,'userdata');
if get(findobj('tag','check_overwrite'),'value')
    h.p = trackcomplete(h.p,'override',1);
else
    h.p = trackcomplete(h.p);
end
set(mainfig,'userdata',h);


%-----------------------------------------------------------------
% button verify callback
%-----------------------------------------------------------------
function button_verify_track_callback(src,evt)
mainfig = findall(0,'tag','schnitzcells_figure');
h = get(mainfig,'userdata');
h.p = schnitzedit(h.p);
set(mainfig,'userdata',h);


%-----------------------------------------------------------------
% ESC handler for track figure
%-----------------------------------------------------------------
function track_esc_handler_callback(src,evt)
if isequal(evt.Key,'escape')
    set(findall(0,'tag','schnitzcells_figure'),'userdata',[]);
    close(findall(0,'tag','track_figure'));
end




%-----------------------------------------------------------------
% setup plot figure
%-----------------------------------------------------------------
function setup_plot_figure

fig = figure('numbertitle','off',...
    'name','SCHNITZCELLS - PLOTTING',...
    'dock','off',...
    'menubar','none',...
    'handlevisibility','off',...
    'toolbar','none',...
    'resize','off',...
    'tag','plot_figure',...
    'color',[0.7 0.7 0.7],...
    'closerequest',@close_plot_figure,...
    'keypressfcn',@plot_esc_handler_callback,...
    'visible','off');

% position under main figure
mainfig = findall(0,'tag','schnitzcells_figure');
mfpos = get(mainfig,'position');
set(fig,'position',[mfpos(1)+100 mfpos(2)-140 250 200]);

% create uicontrols
button_compile = uicontrol(fig,'style','push',...
    'pos',[100 150 120 34],...
    'string','Compile Data',...
    'keypress',@plot_esc_handler_callback,...
    'callback',@button_compile_callback);

text_xaxis = uicontrol(fig,'style','text',...
    'pos',[30 110 140 20],...
    'horizontal','left',...
    'string','Select X axis');

text_yaxis = uicontrol(fig,'style','text',...
    'pos',[30 80 140 20],...
    'horizontal','left',...
    'string','Select Y axis');

popup_xaxis = uicontrol(fig,'style','popup',...
    'pos',[120 100 100 32],...
    'tag','popup_xaxis',...
    'value',1,...
    'string',blanks(0),...
    'keypress',@plot_esc_handler_callback);

popup_yaxis = uicontrol(fig,'style','popup',...
    'pos',[120 70 100 32],...
    'tag','popup_yaxis',...
    'value',1,...
    'string',blanks(0),...
    'keypress',@plot_esc_handler_callback);
    
button_plot = uicontrol(fig,'style','push',...
    'pos',[100 20 120 34],...
    'string','Plot',...
    'keypress',@plot_esc_handler_callback,...
    'callback',@button_schplot_callback);

button_help = uicontrol(fig,'style','push',...
    'cdata',get_png_icon(['private' filesep 'help_icon.png']),...
    'pos',[30 30 40 40],...
    'keypress',@plot_esc_handler_callback,...
    'callback',@button_help_callback);


h = get(mainfig,'userdata');
handles.p = h.p;
handles.channels = h.channels;
handles.num_frames = h.num_frames;

set(fig,'userdata',handles);
set(fig,'visible','on');




%-----------------------------------------------------------------
% close request for plot figure
%-----------------------------------------------------------------
function close_plot_figure(src,evt)
delete(findall(0,'tag','schplot_figure'));
delete(findall(0,'tag','plot_figure'));


%-----------------------------------------------------------------
% button compile callback
%-----------------------------------------------------------------
function button_compile_callback(src,evt)
mainfig = findall(0,'tag','schnitzcells_figure');
h = get(mainfig,'userdata');

try
    [h.p,s] = compileschnitz(h.p);
    xpop = findobj('tag','popup_xaxis');
    ypop = findobj('tag','popup_yaxis');
    set(xpop,'string',{'frames'  'mins'});
    set(ypop,'string',{'MY' 'MR' 'MG' 'MC' 'len'});

    h.s = s;   
    set(mainfig,'userdata',h);
    assignin('base','s',s);
    disp(s);
catch
    msgbox('Schnitz compilation error, recheck Schnitzedit.','Schnitzcells','error','modal');
end



%-----------------------------------------------------------------
% button verify callback
%-----------------------------------------------------------------
function button_schplot_callback(src,evt)

mainfig = findall(0,'tag','schnitzcells_figure');
h = get(mainfig,'userdata');
% h.p = schnitzedit(h.p);
xpop = findobj('tag','popup_xaxis');
ypop = findobj('tag','popup_yaxis');

xval = get(xpop,'value');
xstr = get(xpop,'string');
yval = get(ypop,'value');
ystr = get(ypop,'string');

if isempty(xstr) || isempty(ystr)
    msgbox('You must compile first.','Schnitzcells','error','modal');
    return
end
    
x = xstr{xval};
y = ystr{yval};

f = figure('tag','schplot_figure');

plotschnitzme(h.s,x,y,[]);

% set(mainfig,'userdata',h);


%-----------------------------------------------------------------
% ESC handler for plot figure
%-----------------------------------------------------------------
function plot_esc_handler_callback(src,evt)
if isequal(evt.Key,'escape')
    set(findall(0,'tag','schnitzcells_figure'),'userdata',[]);
    close(findall(0,'tag','track_figure'));
end



