function [s]= recalc_schnitz2(p,varargin);

tR=p.trackRange;
schnitznum=1;
firstframe=p.trackRange(2);
Props=varargin{1};

for framenum = 2:length(p.trackRange);
    mynum_t= str3(tR(framenum));
    yesterdayFrameNum = tR(framenum-1);
    mynum_y= str3(yesterdayFrameNum);


    trackOutputFile = [p.tracksDir,p.movieName,'-tps-output-',...
        mynum_y,'-to-',mynum_t,'.txt'];


    m = load( trackOutputFile ,'ASCII');

    sz=size(m(:),1)/4;
    m=reshape(m,[sz,4]);

    P1=m(:,1);
    P2=m(:,4);
    D=m(:,[2 3]);

    
    

    %%%====== The following section is written only because the tracking program has bugs !!!==========

    singledauhter=setdiff(setxor(D(:,1),D(:,2)),0);
    if ~isempty(singledauhter)
        disp(trackOutputFile)
        disp(['cells # ',num2str(singledauhter(1)), ' has only one daughter!!']);
    end
    daughterandself=setdiff(intersect(P1,unique(D)),0);
    if ~isempty(daughterandself)
        disp(trackOutputFile)
        disp(['cells # ',num2str(daughterandself), ' appear both as continuing and parents!! - saving only parent role']);
        I=find(ismember(P1,daughterandself));
        m(I,1)=0;
    end

    mb=m>0;
    I=find(sum(mb(:,1:3)')>1);
    if ~isempty(I)
        disp(trackOutputFile)
        disp('some cells have more than one predeccesor - keeping first daughter');
        m(I,1)=0;
        J=find(m(I,2)>0);
        m(I(J),3)=0;
    end

    a=load([p.segmentationDir,p.movieName,'seg',str3(tR(framenum))]);
    Imageids=setdiff(unique(a.Lc),0);
    clear a;
    InImageButNotTracked=setdiff(Imageids,P2);
    InTrackedButNotImage=setdiff(P2,Imageids);
    if ~isempty(InImageButNotTracked)
        %disp(['cells #',num2str(InImageButNotTracked),' were not tracked - adding them with no ancestors']);
        for i=1:length(InImageButNotTracked);
            m=[m;[0 0 0 InImageButNotTracked(i)]];
        end
    end

    if ~isempty(InTrackedButNotImage)
        disp(['reported cells #',num2str(InTrackedButNotImage'),' do not exist - earasing'])
        I=setdiff(1:length(P2),find(ismember(P2,InTrackedButNotImage)));
        m=m(I,:);
    end

    %     if p.MaxSplit==1
    %         D=D*0;
    %     end
    %
    %define the first schnitzes in the first populated frame
    ycells=setdiff(unique(m(:,1:3)),0);
    P1=m(:,1);
    P2=m(:,4);
    D=m(:,[2 3]);
    
    if tR(framenum)==firstframe; %first frame pair - define initial schnitzes
        for i=1:length(ycells);
            cellid{1}(ycells(i))=schnitznum;
            s(schnitznum).frames(1)=tR(1)+1;
            s(schnitznum).cellno(1)=ycells(i);
            s(schnitznum).P=0;
            schnitznum=schnitznum+1;
        end
        names=[]; %fieldnames(Props{1})  JY change on his computer.
        for i=1:length(cellid{1})
            if cellid{1}(i)>0
                for j=1:length(names)
                    pr=Props{1};
                    s(cellid{1}(i)).(names{j})(1)=pr(ycells(i)).(names{j});
                end
            end
        end
    end

    ParentList=[];
    PredList=[];
    CellList=[];

    for i=1:length(P2)
        pos=find(m(i,1:3)>0);
        if length(pos)>1
            disp(['cell #',num2str(P2(i)),' has more than one ancestor']);
            pos=-1;
        elseif length(pos)==0
            pos=0;
        end

        if ismember(m(i,4),CellList)
            pos=-1;
        end
        if pos==1 & ismember(m(i,1),PredList)
            pos=0;
        end
        if pos>1 & length(find(ParentList==m(i,pos)))>1
            pos=0;
        end

        switch pos
            case 1 %continuing schnitz
                cellid{framenum}(P2(i))=cellid{framenum-1}(m(i,1));
                ParentSchnitz=cellid{framenum}(P2(i));
                N=length(s(ParentSchnitz).frames);
                s(ParentSchnitz).frames(N+1)=tR(framenum)+1;
                s(ParentSchnitz).cellno(N+1)=P2(i);
                CellList=[CellList P2(i)];
                PredList=[PredList m(i,1)];
            case 2
                s(schnitznum).frames(1)=tR(framenum)+1;
                s(schnitznum).cellno(1)=P2(i);
                s(schnitznum).P=cellid{framenum-1}(m(i,2));
                s(cellid{framenum-1}(m(i,2))).D=schnitznum;
                cellid{framenum}(P2(i))=schnitznum;
                schnitznum=schnitznum+1;
                CellList=[CellList P2(i)];
                ParentList=[PredList m(i,2)];
            case 3
                s(schnitznum).frames(1)=tR(framenum)+1;
                s(schnitznum).cellno(1)=P2(i);
                s(schnitznum).P=cellid{framenum-1}(m(i,3));
                s(cellid{framenum-1}(m(i,3))).E=schnitznum;
                cellid{framenum}(P2(i))=schnitznum;
                schnitznum=schnitznum+1;
                CellList=[CellList P2(i)];
                ParentList=[PredList m(i,3)];
            case 0
                s(schnitznum).frames(1)=tR(framenum)+1;
                s(schnitznum).cellno(1)=P2(i);
                s(schnitznum).P=0;
                cellid{framenum}(P2(i))=schnitznum;
                schnitznum=schnitznum+1;
                CellList=[CellList P2(i)];
        end

    end
   
    names=fieldnames(Props{framenum});
    for i=P2'
        if cellid{framenum}(i)
            schn=cellid{framenum}(i);
            Ni=length(s(schn).frames);
            pr=Props{framenum};
            for j=1:length(names)

                s(cellid{framenum}(i)).(names{j})(Ni)=pr(i).(names{j});

            end

        end
    end
end
    % for i=1:length(varargin);
    %     s=toschnitz(cellid,s,varargin{i},varargin{i+1});
    % end

    for i=1:length(s)
        if isempty(s(i).D)
            s(i).D=0;
        end
        if isempty(s(i).E)
            s(i).E=0;
        end
    end