function s= any2(a);
%  s= any2(a);
s= any(any(a));