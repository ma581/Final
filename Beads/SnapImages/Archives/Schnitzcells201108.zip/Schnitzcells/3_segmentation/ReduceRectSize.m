function ReduceRectSize(p)

cd(p.segmentationDir)
n=dir('*seg*');
N=length(n);
for i=1:N
    a=load(n(i).name);
    if isfield(a,'Lc')

        [I,J]=find(a.Lc>0);
        mxI=min(max(I+10),size(a.Lc,1));mnI=max(min(I-10),1);mxJ=min(max(J+10),size(a.Lc,2));mnJ=max(min(J-10),1);
        imrectJ=mnJ:mxJ;
        imrectI=mnI:mxI;
        v1=a.rect(1):a.rect(3);
        v2=a.rect(2):a.rect(4);
        rect=[v1(mnI) v2(mnJ) v1(mxI) v2(mxJ)];
        names = fieldnames(a);
        savelist=['''rect'','];
        for k=1:length(names)
            if isnumeric(a.(names{k}))
                if size(a.(names{k}),1)==size(a.Lc,1)
                    if size(a.(names{k}),2)==size(a.Lc,2)
                        eval([names{k},'=a.(names{k})(imrectI,imrectJ);']);
                        savelist=[savelist,'''',names{k},''','];
                    end
                end
            end

        end
        disp(n(i).name);
        eval(['save(''',n(i).name,''',',savelist,'''-append'');'])
    end

end



