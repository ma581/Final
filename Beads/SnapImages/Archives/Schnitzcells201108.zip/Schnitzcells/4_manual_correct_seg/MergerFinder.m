function [vout,out]=MergerFinder(p,i);

v=p.manualRange;
while i<=length(p.manualRange)
    disp(['checking: ',p.movieName,'seg',str3(v(i))])
    out=MergedInFrame(p,v(i));
    if ~isempty(out)
        vout=i;
        return
    else
        i=i+1;
    end
end
if i>p.manualRange
    vout=-1;
    out=[];
    disp('no more unified cells found');
end
return
function out=MergedInFrame(p,i)
Th1=0.75;
Th2=0.2;

out=[];
A=load([p.segmentationDir,p.movieName,'seg',str3(i)]);
try
    B=load([p.segmentationDir,p.movieName,'seg',str3(i-1)]);
catch
    %out=[-1 -1 -1];
    return
end
if existfield(A,'Lc')

    Lc1=A.Lc;
else
    return
end
if existfield(B,'Lc')

    Lc2=B.Lc;
else
    return
end

Z=zeros(max(size(Lc1),size(Lc2)));
Z1=Z;
Z2=Z;
Z1(1:size(Lc1,1),1:size(Lc1,2))=Lc1;
Z2(1:size(Lc2,1),1:size(Lc2,2))=Lc2;
%f=LocalRegister(Z1>0,Z2>0,0);
C = normxcorr2(Z1,Z2);
[I,J]=find(C==max2(C));
f=[I J]-size(Z1);
Z2n=shiftC(Z2,-f);

r=unique(Z1);
count=1;
for k=1:length(r)-1;
    v=Z2n(find(Z1==r(k+1)));
    m{k}=unique(v);
    n{k}=hist(v,m{k});
    n{k}=n{k}/sum(n{k});
    Imx=find(n{k}>Th1);
    if isempty(Imx);
        Imxn=find(n{k}>Th2);
        if m{k}(1)==0;
            Imxn=setdiff(Imxn,1);
        end
        if length(Imxn)>1
            out{count}=[r(k+1) m{k}(Imxn)'];
            count=count+1;
        end
    end
end

return
