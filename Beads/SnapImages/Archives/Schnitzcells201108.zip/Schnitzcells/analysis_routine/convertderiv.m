histpulses = [];
pulses = []
m = 1;

for n = 1:length(areapulsetotal)
for m = 1:length(areapulsetotal(n))
pulses = [ pulses areapulsetotal{n}];
end
end
erm = 1
for d = 1:length(pulses)
    %arbitarily ignore pulses smaller than 0.03
if pulses(d) >0.03
histpulses(m) = pulses(d)
m =m+1
end
end
figure
hist(histpulses)