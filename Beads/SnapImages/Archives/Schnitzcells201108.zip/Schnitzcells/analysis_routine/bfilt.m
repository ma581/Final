function y = bfilt(x);
% Blaise Filter

if (size(x,2)<size(x,1))
   x = x';
   iamvert = 1;
else
   iamvert = 0;
end

xx=x;
clear x;
for i = 1:size(xx,1)
    x = xx(i,:);
    m(1,:)=[x(3) x(2) x(1:end-2)];
    m(2,:)=[x(2) x(1:end-1)];
    m(3,:)=x;
    m(4,:)=[x(2:end) x(end-1)];
    m(5,:)=[x(3:end) x(end-1) x(end-2)];
    b=[0 .25 .5 .25 0];
    y(i,:)=b*sort(m);
end
if iamvert
   y = y';
end
