
function y = str2(x);

y = num2str(x,'%1.2d');

