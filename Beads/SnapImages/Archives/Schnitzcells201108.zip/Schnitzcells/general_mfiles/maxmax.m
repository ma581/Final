
function y = max(x);
y = double(max(max(x)));