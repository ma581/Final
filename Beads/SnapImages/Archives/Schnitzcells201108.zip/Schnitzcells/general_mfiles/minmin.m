
function y = max(x);
y = double(min(min(x)));