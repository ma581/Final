%This is written for Metamorph MultiDimensional Output, but can be
%modified for other acquistion software.

%Four strings need to be defined in the code:
%1.Name:  The name of the movie
%2.Channel:  YFP, CFP, GFP, phase need to be mapped to one-letter codes.
%3.Stagepos:  The stage position of the movie.
%4.Timepoint:  The time, or frame, of the movie.


delete('*_thumb_*');
delete('*[None]*');
D = dir('*_*');


for j = 1 : length(D)
setpoints = findstr(D(j).name,'_');  %How the output parses the file name.
name = D(j).name(1:setpoints(1)-1);
channel = D(j).name(setpoints(1)+1:setpoints(2)-1);
stagepos = D(j).name(setpoints(2)+2:setpoints(3)-1);
timepoint = D(j).name(setpoints(3)+2:end-4);
if(findstr('Alex',channel))
    newchannel = 't'; %Fixed value
else
    if(findstr('CFP',channel))
        newchannel = 'c';  %Fixed value
    else
        if(findstr('rightfield',channel))
            newchannel = 'p'; %Fixed value
        else
            if(findstr('YFP',channel))
                newchannel = 'y'; %Fixed value
            end
        end
    end
end
newname = [name,'-',str2(str2num(stagepos)),'-',newchannel,'-',str3(str2num(timepoint)),'.tif'] %Shouldn't change unless you know what you're doing.
movefile(D(j).name,newname);
end