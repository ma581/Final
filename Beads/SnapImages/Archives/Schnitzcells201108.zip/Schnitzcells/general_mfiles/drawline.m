function varargout = drawline(oldim,pt1,pt2,color)
% function newim = drawline(oldim,pt1,pt2,color);

ptc=[];
vec = [pt2(1) - pt1(1) , pt2(2)-pt1(2)];
D = sqrt(sum(vec.^2));
newim=oldim;
if (D==0)
    newim(pt1(1),pt1(2)) = color;
else
    for d = 0:0.25:D
        thispt = round(pt1 + vec*d/D);
        newim(thispt(1), thispt(2)) = color;
        if nargout==2
            ptc=[ptc  oldim(thispt(1), thispt(2))];
        end
    end
end

if nargout>=1
    varargout{1}=newim;
end
if nargout==2
    varargout{2}=ptc;
end
