This is a 20 frame test movie that can be analyzed using the following MATLAB commands (see below):

For video tutorials of this process, please refer to the schnitzedit website.

Note:  It is first necessary to add the folder 'Schnitzcells' and it's subdirectories to the MATLAB path, which will allow you to call the following commands.

1) >> p = initschnitz('TestSchnitz-01','2010-04-27','bacillus','rootDir','D:\TestSchnitzImgs','imageDir','D:\TestSchnitzImgs');

	%Note:  You may need to change the path of 'rootDir' and 'imageDir' depending on where you place the directory.  


2a) >> p = segmoviefluor(p);   %This uses the 't' fluorescent channel to segment cells.  Each frame should be "cropped" during the 'p = manualcheckseg(p)'

             OR (use either 2a or 2b only)

2b) >> p = segmoviephase(p);   %This uses the phase image to segment cells 


3) >> p = manualcheckseg(p,'override',1);   %Reviewing and editing segmentation.

4) >> p = trackcomplete(p);  %Tracking cells

5) >> p = schnitzedit(p); %Reviewing and editing tracking

6) >> [p,s] = compileschnitz(p);  %Extracts data from the images and creates the 's' MATLAB data structure

7) >> plotschnitzme(s,'frames','MY') %Example Plot:  Mean YFP fluorescence versus frame number